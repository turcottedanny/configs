# Geany Tango Dark colour scheme
This theme is a simple, Tango! palette-based colour scheme for Geany, with a dark base. The colours are loosely based on the Dark Geany project.

Languages currently supported:

 * Python (contributed by batisteo)
 * C
 * C++
 * CSS (including CSS3 and browser vendor prefixes)
 * HTML
 * Java
 * JavaScript
 * PHP
 * SGML
 * Shell scripts
 * XHTML
